version = 12

android {
    sourceSets.getByName("main").kotlin.directories += listOf(
        rootProject.file("TurkSinema/src/main/kotlin/dev/wiojelt/turksinema/vendor/wio_diziasya").path,
        rootProject.file("common/src/main/kotlin").path
    )
}

cloudstream {
    language = "tr"
    description = "DiziAsya · Kore, Japon ve Çin Dizileri & Asya Sineması (diziasya.com)"
    status = 3
    tvTypes = listOf("AsianDrama", "TvSeries", "Movie")
    iconUrl = "https://diziasya.com/apple-touch-icon.png"
}
